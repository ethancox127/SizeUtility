package main

import "github.com/ethancox127/size/cmd"

func main() {
	cmd.Execute()
}
